/*
  NuvrixSol Shopify setup
  1) Replace YOUR-STORE.myshopify.com with your Shopify store domain.
  2) Paste a Storefront API public access token from Shopify into storefrontAccessToken.
  This is a PUBLIC storefront token; never put an Admin API access token here.
*/
window.NUVRIX_SHOPIFY = {
  storeDomain: "YOUR-STORE.myshopify.com",
  storefrontAccessToken: "PASTE_STOREFRONT_PUBLIC_ACCESS_TOKEN_HERE",
  apiVersion: "2026-07",
  currencyFallback: "USD"
};
